package com.mindex.challenge.service.impl;

import com.mindex.challenge.data.Compensation;
import com.mindex.challenge.data.Employee;
import com.mindex.challenge.service.CompensationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class CompensationServiceTest {

    @Autowired
    private CompensationService compensationService;

    private Employee testEmployee;

    @BeforeEach
    public void setup() {
        testEmployee = new Employee();
        testEmployee.setEmployeeId("123");
        testEmployee.setFirstName("John");
        testEmployee.setLastName("Doe");
    }

    @Test
    public void testCreateAndReadCompensation() {
        Compensation compensation = new Compensation(testEmployee, 75000, LocalDate.of(2024, 5, 1));

        // Create Compensation
        Compensation createdComp = compensationService.create(compensation);
        assertNotNull(createdComp, "Created compensation should not be null");
        assertEquals(75000, createdComp.getSalary(), "Salary should match");
        assertEquals(LocalDate.of(2024, 5, 1), createdComp.getEffectiveDate(), "Effective date should match");

        // Read Compensation
        Compensation fetchedComp = compensationService.read("123");
        assertNotNull(fetchedComp, "Fetched compensation should not be null");
        assertEquals(createdComp.getSalary(), fetchedComp.getSalary(), "Fetched salary should match");
        assertEquals(createdComp.getEffectiveDate(), fetchedComp.getEffectiveDate(), "Fetched effective date should match");
    }
}
