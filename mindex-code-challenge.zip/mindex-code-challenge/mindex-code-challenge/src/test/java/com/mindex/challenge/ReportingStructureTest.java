package com.mindex.challenge.data;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ReportingStructureTest {

    @Test
    public void testReportingStructureGettersAndSetters() {
        Employee testEmployee = new Employee();
        testEmployee.setEmployeeId("123");
        testEmployee.setFirstName("John");
        testEmployee.setLastName("Doe");

        ReportingStructure reportingStructure = new ReportingStructure();
        reportingStructure.setEmployee(testEmployee);
        reportingStructure.setNumberOfReports(5);

        // Verify values
        assertEquals(testEmployee, reportingStructure.getEmployee(), "Employee should match");
        assertEquals(5, reportingStructure.getNumberOfReports(), "Number of reports should be 5");
    }
}
