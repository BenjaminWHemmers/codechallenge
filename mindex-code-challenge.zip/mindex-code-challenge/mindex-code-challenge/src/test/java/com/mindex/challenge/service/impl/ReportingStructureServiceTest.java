package com.mindex.challenge.service.impl;

import com.mindex.challenge.data.Employee;
import com.mindex.challenge.data.ReportingStructure;
import com.mindex.challenge.dao.EmployeeRepository;
import com.mindex.challenge.service.ReportingStructureService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)  // Use Spring JUnit 5 extension
public class ReportingStructureServiceTest {

    @Autowired
    private ReportingStructureService reportingStructureService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void testReportingStructureCalculation() {
        Employee john = new Employee();
        john.setEmployeeId("1");

        Employee paul = new Employee();
        paul.setEmployeeId("2");

        Employee ringo = new Employee();
        ringo.setEmployeeId("3");

        Employee pete = new Employee();
        pete.setEmployeeId("4");

        Employee george = new Employee();
        george.setEmployeeId("5");

        // Setup direct reports
        ringo.setDirectReports(Arrays.asList(pete, george)); // Ringo has Pete & George
        john.setDirectReports(Arrays.asList(paul, ringo)); // John has Paul & Ringo

        // Save employees in database (only for integration testing)
        employeeRepository.save(john);
        employeeRepository.save(paul);
        employeeRepository.save(ringo);
        employeeRepository.save(pete);
        employeeRepository.save(george);

        // Run test
        ReportingStructure resultJohn = reportingStructureService.getReportingStructure("1");
        ReportingStructure resultRingo = reportingStructureService.getReportingStructure("3");

        // Validate results
        assertEquals(4, resultJohn.getNumberOfReports(), "John should have 4 reports");
        assertEquals(2, resultRingo.getNumberOfReports(), "Ringo should have 2 reports");
    }
}
