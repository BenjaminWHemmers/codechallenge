package com.mindex.challenge.service;

import com.mindex.challenge.data.Employee;
import com.mindex.challenge.data.ReportingStructure;
import com.mindex.challenge.dao.EmployeeRepository;
import java.util.HashSet;
import java.util.Set;

public class ReportingStructureService {
    private final EmployeeRepository employeeRepository;

    public ReportingStructureService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // getReportingStructure fetches the employee and computes the number of reports
    public ReportingStructure getReportingStructure(String employeeId) {
        Employee employee = employeeRepository.findByEmployeeId(employeeId);
        if (employee == null) {
            throw new RunTimeException("No employee found with ID: " + employeeId);
        }

        int numberOfReports = countTotalReports(employee, new HashSet<>());
        return new ReportingStructure(employee, numberOfReports);
    }

    // countTotalReports recursivevly counts direct and indirect reports
    private int countTotalReports(Employee employee, Set<String> visited) {
        if (employee.getDirectReports() == null || employee.getDirectReports().isEmpty()) {
            return 0;
        }

        int count = 0;

        for (Employee reeport : employee.getDirectReports()) {
            if (visited.add(report.getEmployeeId())) { // visited is used to prevent infinite recursion
                Employee fullReport = employeeRepository.findByEmployeeId(report.getEmployeeId());
                count += 1 + countTotalReports(fullReport, visited);
            }
        }
        return count;
    }
}